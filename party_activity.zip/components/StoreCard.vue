<template>
	<view class="store-item">
		<view class="store-content">
			<view class="store-header">
				<view class="store-name">
					<uni-icons :type="store.icon" size="20" color="#FF6B00"></uni-icons>
					<text>{{ store.storeName }}</text>
				</view>
				<view class="distance" v-if="store.distanceKm">
					<uni-icons type="location-filled" size="16" color="#FF6B00"></uni-icons>
					<text>{{ store.distanceKm }}</text>
				</view>
			</view>
			<view class="store-desc">
				{{ store.storeDescription }}
			</view>
			<view class="store-footer">
				<!-- 修改点 1：将原来的标签区域替换为“发起聚会”按钮 -->
				<button class="nav-btn initiate-btn" @click.stop="handleInitiateParty">
					<text>发起聚会</text>
				</button>

				<button class="nav-btn detail-btn" @click.stop="handleCardClick">
					<text>聚店详情</text>
				</button>
			</view>
		</view>
	</view>
</template>

<script setup>
	import {
		defineProps,
		defineEmits,
		computed
	} from 'vue';

	const props = defineProps({
		store: {
			type: Object,
			required: true,
		},
	});

	const emit = defineEmits(['click-card']);

	const formattedDistance = computed(() => {
		if (typeof props.store.distance !== 'number') {
			return null;
		}

		// 修改点 3：将 Math.floor() 改为 toFixed(2) 以保留两位小数
		const distanceWithDecimals = props.store.distance.toFixed(2);
		return `${distanceWithDecimals}公里`;
	});

	const handleCardClick = () => {
		emit('click-card', props.store);
	};

	/**
	 * 处理“发起聚会”按钮的点击事件
	 */
	// const handleInitiateParty = () => {
	// 	// 跳转到发起聚会页面，并通过 query 参数传递店铺 ID
	// 	uni.navigateTo({
	// 		url: `/packages/active-publish/active-publish?storeId=${props.store.id}`
	// 	});
	// };
	/**
	 * 处理“发起聚会”按钮的点击事件
	 */
	const handleInitiateParty = () => {
		// 1. 安全检查，确保 store 对象和 id 存在
		if (!props.store || !props.store.id) {
			uni.showToast({
				title: '聚店信息不完整',
				icon: 'none'
			});
			return;
		}

		// ==================== 【核心修改点】 ====================
		// 2. 在 URL 中同时传递 storeId 和 storeName
		//    使用 encodeURIComponent 对店名进行编码，防止特殊字符（如 &、?、空格）破坏URL结构
		const url =
			`/packages/active-publish/active-publish?storeId=${props.store.id}&storeName=${encodeURIComponent(props.store.storeName)}`;
		// =======================================================

		// 3. 执行跳转
		uni.navigateTo({
			url: url
		});
	};
</script>

<style lang="scss" scoped>
	/* ... (其他样式保持不变) ... */
	:root {
		--primary: #FF6B00;
		--primary-light: #FF8A33;
		--light-bg: #f8f8f8;
		--dark-text: #333;
		--gray-text: #666;
		--light-text: #999;
		--border: #eee;
		--weui-BG-0: #ededed;
		--weui-BG-1: #f7f7f7;
	}

	.store-item {
		background: white;
		border-radius: 12px;
		margin-bottom: 15px;
		box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
		overflow: hidden;
		transition: all 0.3s ease;
	}

	.store-item:active {
		transform: scale(0.98);
	}

	.store-content {
		padding: 15px;
	}

	.store-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 12px;
	}

	.store-name {
		font-size: 18px;
		font-weight: 600;
		color: var(--dark-text);
		display: flex;
		align-items: center;

		flex: 1;
		/* 1. 让它占据所有剩余空间，这是最关键的一步 */
		min-width: 0;
		/* 2. 允许 flex 项在内容溢出时收缩，这是 flex 布局的一个重要技巧 */
	}

	.store-name .uni-icons {
		margin-right: 8px;
		flex-shrink: 0;
	}

	.store-name text {
		white-space: nowrap;
		/* 禁止文本换行 */
		overflow: hidden;
		/* 隐藏超出的部分 */
		text-overflow: ellipsis;
		/* 将隐藏的部分显示为省略号 */
		display: inline-block;
		/* 确保 text 元素表现为块级行为，以便应用溢出样式 */
		vertical-align: middle;
		/* (可选) 确保文本和图标垂直对齐更精确 */
	}

	.distance {
		color: var(--primary);
		font-size: 14px;
		display: flex;
		align-items: center;
		font-weight: 500;

		margin-left: 10px;
		/* 5. (推荐) 给距离增加一个左边距，确保即使店名不长，两者之间也有安全间距 */
		flex-shrink: 0;
		/* 6. (推荐) 确保距离部分本身不会被压缩 */
	}

	.distance .uni-icons {
		margin-right: 4px;
	}

	.store-desc {
		font-size: 14px;
		color: var(--gray-text);
		margin-bottom: 15px;
		line-height: 1.5;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.store-footer {
		display: flex;
		justify-content: flex-end;
		/* 修改为 flex-end，让按钮靠右对齐 */
		align-items: center;
		padding-top: 10px;
		border-top: 1px dashed #ffe8d9;
		gap: 10px;
		/* 新增：给按钮之间增加一些间距 */
	}

	/* 移除 .store-tags 和 .store-tag 的样式 */

	.nav-btn {
		/* 这是两个按钮的通用样式 */
		color: white;
		border: none;
		padding: 6px 18px;
		border-radius: 16px;
		font-size: 14px;
		display: flex;
		align-items: center;
		cursor: pointer;
		transition: all 0.3s;
		font-weight: 500;
		line-height: 1;
		margin: 0;
	}

	.nav-btn::after {
		border: none;
	}

	/* 新增：“发起聚会”按钮的特定样式 */
	.initiate-btn {
		background: #FF8A33;
		/* 使用一个稍浅的橙色以作区分 */
	}

	/* 修改：“聚店详情”按钮的样式 */
	.detail-btn {
		background: var(--primary);
		/* 使用主色 */
	}

	.nav-btn .uni-icons {
		margin-right: 5px;
	}
</style>